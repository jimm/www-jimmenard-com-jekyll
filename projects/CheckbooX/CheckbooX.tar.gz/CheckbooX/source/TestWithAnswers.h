// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import <SenTestingKit/SenTestingKit.h>

@class Checkbook;

// This abstract class knows how to read an XML file containing answers.
@interface TestWithAnswers : SenTestCase
{
    NSDictionary *answers;
}

-(void)readAnswersFrom:(NSString *)filePath;

-(NSString *)answerAsString:(NSString *)answerName;
-(int)answerAsInt:(NSString *)answerName;
-(long)answerAsLong:(NSString *)answerName;
-(float)answerAsFloat:(NSString *)answerName;
-(BOOL)answerAsBool:(NSString *)answerName;

@end
