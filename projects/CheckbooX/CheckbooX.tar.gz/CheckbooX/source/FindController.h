// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import <Cocoa/Cocoa.h>

@class CheckbookEntry;

@interface FindController : NSWindowController
{
    IBOutlet id checkbook;
    IBOutlet id checkbookController;
    IBOutlet id parentWindow;
    IBOutlet id fpDate;
    IBOutlet id fpCheckNumber;
    IBOutlet id fpDescription;
    IBOutlet id fpDeposit;
    IBOutlet id fpWithdrawal;

    CheckbookEntry *template;
    int lastFoundIndex;
}

- init;
- (void)dealloc;

- (IBAction)openFindPanel:(id)sender;
- (IBAction)performFind:(id)sender;
- (IBAction)doneFinding:(id)sender;
- (IBAction)performFindNext:(id)sender;
- (IBAction)performFindPrevious:(id)sender;

@end
