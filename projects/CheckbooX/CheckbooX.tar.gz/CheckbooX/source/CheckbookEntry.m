// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import <math.h>
#import "CheckbookEntry.h"

//#DEFINE MATCH_DEBUG 1

@implementation CheckbookEntry

- init
{
    self = [super init];
    if (self != nil) {
        date = [NSCalendarDate date];
        [date retain];
        checkNumber = 0;
        description = @"Description";
        amountInPennies = 0;
        marked = NO;
    }
    return self;
}
    
- (void)dealloc
{
    [date release];
    [super dealloc];
}

// Returns YES if this entry matches the template. Used by the checkbook when performing a find.
- (BOOL)matches:(CheckbookEntry *)template
{
    if ([template date] != nil) {
        // Match dates that are the same or later than template date
        if ([[template date] timeIntervalSinceDate:date] > 0)
            return NO;
/*
	if (([[template date] yearOfCommonEra] != [date yearOfCommonEra])
	    || ([[template date] monthOfYear] != [date monthOfYear])
	    || ([[template date] dayOfMonth] != [date dayOfMonth])) {
#if defined(MATCH_DEBUG)
	    NSLog(@"date failed");
#endif
	    return NO;
	}
*/
    }
    if ([template checkNumber] != 0 && [template checkNumber] != checkNumber) {
#if defined(MATCH_DEBUG)
	NSLog(@"check number failed");
#endif
	return NO;
    }
    if ([template amountInPennies] != 0 && [template amountInPennies] != amountInPennies) {
#if defined(MATCH_DEBUG)
	NSLog(@"amount failed");
#endif
	return NO;
    }
    if ([template description] != nil && [[template description] length] > 0) {
	if (description == nil)
	    return NO;
	else {
	    NSRange range = [description rangeOfString:[template description] options:NSCaseInsensitiveSearch];
	    if (range.location == NSNotFound) {
#if defined(MATCH_DEBUG)
		NSLog(@"desc failed; templ string = %@, my desc = %@", [template description], description);
#endif
		return NO;
	    }
	}
    }
#if defined(MATCH_DEBUG)
    NSLog(@"MATCH!");
#endif
    return YES;
}

- (NSCalendarDate *)date { return date; }

- (void)setDate:(NSCalendarDate *)aDate
{
    [date release];
    date = aDate;
    [date retain];
    [self setChanged:YES];
}

- (int)checkNumber { return checkNumber; }

- (void)setCheckNumber:(int)anInt {
    checkNumber = anInt;
    [self setChanged:YES];
}

- (NSConstantString *)description { return description; }

- (void)setDescription:(NSConstantString *)aString
{
    [description release];
    description = aString;
    [description retain];
    [self setChanged:YES];
}

- (float)amount { return (float)amountInPennies / 100.0; }

// Used by the checkbook when calculating balances
- (long)amountInPennies { return amountInPennies; }

- (void)setAmount:(float)aFloat {
    amountInPennies = lroundf(aFloat * 100.0);
    [self setChanged:YES];
}

- (void)setAmountInPennies:(long)aLong {
    amountInPennies = aLong;
    [self setChanged:YES];
}

- (BOOL)isMarked { return marked; }

- (void)setMarked:(BOOL)aBool {
    marked = aBool;
    [self setChanged:YES];
}

- (BOOL)isChanged
{
    return changed;
}

- (void)setChanged:(BOOL)aBool
{
    changed = aBool;
}

@end
