// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import <Cocoa/Cocoa.h>

@interface CheckbookController : NSWindowController
{
    IBOutlet id checkbook;
    IBOutlet id table;
    IBOutlet id balance;
    IBOutlet id markedBalancesCheckbox;
    IBOutlet id toggleShowCheckmarkedMenuItem;
    NSString *filename;
    BOOL windowClosed;
    BOOL displayMarkedItems;
}

- init;
- (void)dealloc;

- (IBAction)add:(id)sender;
- (IBAction)new:(id)sender;
- (IBAction)open:(id)sender;
- (IBAction)revert:(id)sender;
- (IBAction)save:(id)sender;
- (IBAction)saveAs:(id)sender;
- (IBAction)showMarkedBalance:(id)sender;
- (IBAction)sort:(id)sender;
- (IBAction)toggleDisplayMarkedItems:(id)sender;
- (IBAction)toggleItemMark:(id)sender;

- (void)selectRow:(int)rowIndex;

- (void)awakeFromNib;

// Window delegate methods
- (BOOL)windowShouldClose:(NSWindow *)sender;
- (void)windowWillClose:(NSNotification *)notification;

// Applicatin delegate methods
- (NSApplicationTerminateReply)applicationShouldTerminate:(id)sender;

@end

@interface CheckbookController (TableDataSource)

    // Table view data source methods
- (int)numberOfRowsInTableView:(NSTableView *)aTableView;
- (id)tableView:(NSTableView *)aTableView
objectValueForTableColumn:(NSTableColumn *)aTableColumn
		   row:(int)rowIndex;
- (void)tableView:(NSTableView *)aTableView
   setObjectValue:anObject
   forTableColumn:(NSTableColumn *)aTableColumn
		     row:(int)rowIndex;

@end
