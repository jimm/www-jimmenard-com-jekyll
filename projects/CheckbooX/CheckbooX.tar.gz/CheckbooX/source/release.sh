#! /bin/sh
#
# Release CheckbooX to my Web site.

here=`dirname $0`
this_dirname=`pwd`
this_dirname=`basename $this_dirname`

# Copy this directory to /tmp.
cd $here/..
rm -fr /tmp/$this_dirname
cp -r $this_dirname /tmp

# Clean it up a bit.
cd /tmp/$this_dirname
find . -name '.DS_Store' -delete
mkdir /tmp/source
mv * /tmp/source
mv /tmp/source .
mv source/build/CheckbooX.app "source/CheckbooX Readme.rtf" .
rm -fr source/build

# Tar it up and copy it to my Web site.
archive_name=$this_dirname.tar.gz
cd /tmp
tar -czf $archive_name $this_dirname
du -k $archive_name | cut -f 1 >size.txt
scp $archive_name size.txt "$this_dirname/CheckbooX Readme.rtf" \
	io.com:public-web/projects/CheckbooX

# Remove the copy, tarball, and size file.
rm -r /tmp/$this_dirname /tmp/$this_dirname.tar.gz size.txt
