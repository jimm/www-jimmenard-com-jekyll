// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import "TestCheckbookEntry.h"
#import "Checkbook.h"
#import "CheckbookEntry.h"

// Can anyone help me make this a relative path instead of an absolute path?
#define TEST_CHECKBOOK_FILE @"~/projects/CheckbooX/test_checkbook.xml"
#define TEST_ANSWERS_FILE @"~/projects/CheckbooX/test_entry_answers.xml"

@implementation TestCheckbookEntry

- (void) setUp {
    entry = [[CheckbookEntry alloc] init];
}

- (void) tearDown {
    [entry release];
}

- (void) testEntryAmount {
    [entry setAmountInPennies:123];
    STAssertEquals(123L, [entry amountInPennies],  @"bad amount; 123 != %ld", [entry amountInPennies]);
    STAssertEquals(1.23f, [entry amount], @"bad amount; 1.23 != %f", [entry amount]);

    [entry setAmount:1.23];
    STAssertEquals(123L, [entry amountInPennies],  @"bad amount; 123 != %ld", [entry amountInPennies]);
    STAssertEquals(1.23f, [entry amount], @"bad amount; 1.23 != %f", [entry amount]);
    
    [entry setAmountInPennies:-100004];
    STAssertEquals(-100004L, [entry amountInPennies],  @"bad amount; 123 != %ld", [entry amountInPennies]);
    STAssertEquals(-1000.04f, [entry amount], @"bad amount; 1.23 != %f", [entry amount]);
}

// When matching by date, we want to return YES for all dates >= the given date.
- (void) testMatchesDate {
    Checkbook *checkbook = [[Checkbook alloc] init];
    [checkbook openFile:[TEST_CHECKBOOK_FILE stringByExpandingTildeInPath]];
    [self readAnswersFrom:[TEST_ANSWERS_FILE stringByExpandingTildeInPath]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] initWithDateFormat:@"%m/%d/%y" allowNaturalLanguage:NO];
    NSCalendarDate *templateDate;
    BOOL conversionResult;
    NSString *error;
    
    conversionResult = [dateFormatter getObjectValue:&templateDate forString:[self answerAsString:@"startBalanceDateString"] errorDescription:&error];
    STAssertEquals(YES, conversionResult, error);
    
    CheckbookEntry *template = [[CheckbookEntry alloc] init];
    [template setDate:templateDate];
    [template setDescription:nil]; // Erase default description

    int i, numEntries = [self answerAsInt:@"numEntries"];
    for (i = 0; i < numEntries; ++i) {
        [entry release];
        entry = [checkbook entryAt:i];
        [entry retain];
        STAssertTrue([entry matches:template], nil);
    }
}

@end
