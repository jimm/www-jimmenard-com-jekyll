// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import "FindController.h"
#import "Checkbook.h"
#import "CheckbookEntry.h"
#import "CheckbookController.h"

@interface FindController (Private)
- (void)goTo:(int)index;
@end

@implementation FindController

- init
{
    self = [super init];
    if (self != nil) {
        template = [[CheckbookEntry alloc] init];
        [template setDate:nil];
    }
    return self;
}

- (void)dealloc
{
    [template release];
    [template dealloc];
}

- (IBAction)openFindPanel:(id)sender
{
    [NSApp beginSheet:[self window] modalForWindow:parentWindow
	       modalDelegate:self didEndSelector:NULL contextInfo:nil];
}

- (IBAction)performFind:(id)sender
{
    NSDateFormatter *dateFormatter = [fpDate formatter];
    NSCalendarDate *templateDate;
    BOOL conversionResult;
    NSString *error;

    // Fill the template
    conversionResult = [dateFormatter getObjectValue:&templateDate forString:[fpDate stringValue] errorDescription:&error];
    if (conversionResult == NO) {
	NSLog(error);
	NSBeginInformationalAlertSheet(@"Date Error", @"Close", nil, nil, parentWindow, nil, nil, nil, nil, error);
	templateDate = nil;
    }

    [template setDate:templateDate];
    [template setCheckNumber:[fpCheckNumber intValue]];
    [template setDescription:(NSConstantString *)[fpDescription stringValue]];
    if ([fpDeposit floatValue] > 0)
	[template setAmount:[fpDeposit floatValue]];
    else if ([fpWithdrawal floatValue] > 0)
	[template setAmount:-[fpWithdrawal floatValue]];
    else
	[template setAmount:0];

    // Perform the search
    [self goTo:[checkbook findLike:template from:0]];

    // Close the sheet
    [self doneFinding:sender];
}

- (IBAction)doneFinding:(id)sender
{
    [[self window] orderOut:nil];
    [NSApp endSheet:[self window]];
}

- (IBAction)performFindNext:(id)sender
{
    [self goTo:[checkbook findLike:template from:lastFoundIndex+1]];
}

- (IBAction)performFindPrevious:(id)sender
{
    if (lastFoundIndex == -1)
	lastFoundIndex = [checkbook entryCount];
    [self goTo:[checkbook findPreviousLike:template from:lastFoundIndex-1]];
}

@end

@implementation FindController (Private)

- (void)goTo:(int)index
{
    lastFoundIndex = index;
    if (lastFoundIndex >= 0)
	[checkbookController selectRow:lastFoundIndex];
    else
	NSBeep();
}

@end
