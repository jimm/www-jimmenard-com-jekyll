// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import "Checkbook.h"
#import "CheckbookEntry.h"

// Used when sorting the checkbook, this method returns NSOrderedDescending, NSOrderedSame, or NSOrderedAscending.
int entrySort(id thingOne, id thingTwo, void *context)
{
    NSComparisonResult result;

    CheckbookEntry *entry1 = (CheckbookEntry *)thingOne;
    CheckbookEntry *entry2 = (CheckbookEntry *)thingTwo;

    // Compare dates. If they are the same, compare check numbers.
    result = [[entry1 date] compare: [entry2 date]];
    if (result == NSOrderedSame) {
	int diff = [entry1 checkNumber] - [entry2 checkNumber];
	result = (diff == 0 ? NSOrderedSame : (diff > 0 ? NSOrderedDescending : NSOrderedAscending));
    }
    return result;
}

@implementation Checkbook

// The designated initializer.
-init
{
    self = [super init];
    if (self != nil) {
        records = [[NSMutableArray alloc] init];
        firstNewEntry = YES;
    }
    return self;
}

// I'm free!
- (void)dealloc
{
    [records release];
    [super dealloc];
}

// Creates a new checkbook entry at the end of the checkbook. Copies the date from the existing last record, if any. Returns the new entry.
- (CheckbookEntry *)addNewEntry
{
    CheckbookEntry *entry;
    NSCalendarDate *date;
    int numRecords = [records count];

    if (numRecords == 0 || firstNewEntry) {
	date = [NSCalendarDate date];
        firstNewEntry = NO;
    }
    else {
	NSCalendarDate *prevDate = [[records objectAtIndex:(numRecords-1)] date];
	date = [[NSCalendarDate alloc] initWithTimeInterval:0 sinceDate:prevDate];
	[date autorelease];
    }

    entry = [[CheckbookEntry alloc] init];
    [entry autorelease];
    [entry setDate:date];
    [records addObject:entry];
    [self setChanged:YES];
    
    return entry;
}

// Sorts the checkbook by date then by check number. See entrySort.
- (void)sort
{
    [records sortUsingFunction:entrySort context:nil];
    [self setChanged:YES];
}

// Recalculates total balance and marked balance.
- (void)calculateBalance
{
    NSEnumerator *e;
    CheckbookEntry *entry;

    balanceInPennies = markedBalanceInPennies = 0;
    for (e = [records objectEnumerator]; (entry = (CheckbookEntry *)[e nextObject]) != nil; ) {
	balanceInPennies += [entry amountInPennies];
	if ([entry isMarked]) markedBalanceInPennies += [entry amountInPennies];
    }
}

// Returns the total balance.
- (float)balance
{
    return(float)balanceInPennies / 100.0;
}

// Returns the balance of all marked entries.
- (float)markedBalance
{
    return(float)markedBalanceInPennies / 100.0;
}

// Returns YES if this checkbook or any of its entries have been changed.
- (BOOL)isChanged
{
    NSEnumerator *e;
    CheckbookEntry *entry;

    if (changed)
	return YES;
    for (e = [records objectEnumerator]; (entry = (CheckbookEntry *)[e nextObject]) != nil; ) {
	if ([entry isChanged])
	    return YES;
    }
    return NO;
}

// Sets changed flag. If NO, clears flags of all entries.
- (void)setChanged:(BOOL)aBool
{
    NSEnumerator *e;
    CheckbookEntry *entry;

    changed = aBool;
    if (!changed) {
	for (e = [records objectEnumerator]; (entry = (CheckbookEntry *)[e nextObject]) != nil; )
	    [entry setChanged:NO];
    }
}

// Returns the number of checkbook entries.
- (int)entryCount
{
    return [records count];
}

// Returns the number of unmarked entries.
- (int)unmarkedEntryCount
{
    NSEnumerator *e;
    CheckbookEntry *entry;

    int count = 0;
    for (e = [records objectEnumerator]; (entry = (CheckbookEntry *)[e nextObject]) != nil; )
	if (![entry isMarked]) ++count;
    return count;
}

// Returns the specified entry.
- (CheckbookEntry *)entryAt:(int)index
{
    return [records objectAtIndex:index];
}

// Returns the specified unmarked entry, skipping over marked entries.
- (CheckbookEntry *)unmarkedEntryAt:(int)index
{
    NSEnumerator *e;
    CheckbookEntry *entry;
    
    int unmarkedIndex = -1;
    for (e = [records objectEnumerator]; (entry = (CheckbookEntry *)[e nextObject]) != nil; ) {
	if (![entry isMarked]) {
            if (++unmarkedIndex == index)
                return entry;
        }
    }
    return nil;
}

// Toggles the marked attribute of the item at index.
- (void)toggleItemMarkAt:(int)index
{
    [[records objectAtIndex:index] setMarked:![[records objectAtIndex:index] isMarked]];
    [self calculateBalance];
}

// Returns the first checkbook entry matching a template whose index is >= the specified index.
- (int)findLike:(CheckbookEntry *)template from:(int)rowIndex
{
    int i;
    for (i = rowIndex; i < [records count]; ++i) {
	if ([[records objectAtIndex:i] matches:template])
	    return i;
    }
    return -1;
}

// Returns the first checkbook entry matching a template whose index is <= the specified index.
// (Should that perhaps be < the index instead?)
- (int)findPreviousLike:(CheckbookEntry *)template from:(int)rowIndex
{
    int i;
    for (i = rowIndex; i >= 0; --i) {
	if ([[records objectAtIndex:i] matches:template])
	    return i;
    }
    return -1;
}

// Read this checkbook from a  file. We must translate the file contents into checkbook entries.
- (void)openFile:(NSString *)fileName
{
    NSEnumerator *e;
    NSArray *contents = [NSArray arrayWithContentsOfFile:fileName];
    NSDictionary *dictEntry;
    NSCalendarDate *calDate;

    [records release];
    records = [[NSMutableArray alloc] init];
    [records retain];

    // Translate each entry from a dictionary to a checkbook entry
    for (e = [contents objectEnumerator]; (dictEntry = (NSDictionary *)[e nextObject]) != nil; ) {
	CheckbookEntry *entry = [[CheckbookEntry alloc] init];
	NSObject *val;
	long amount;

	// We receive an NSCFDate, which is essentially the same thing as an NSDate.
	// We need an NSCalendarDate.
	val = [dictEntry objectForKey:@"date"];
	calDate = [[NSCalendarDate alloc] initWithTimeInterval:0 sinceDate:(NSDate *)val];
	[calDate autorelease];
	[entry setDate:calDate];

	[entry setCheckNumber:[[dictEntry objectForKey:@"check_num"] intValue]];
	[entry setDescription:[dictEntry objectForKey:@"description"]];
	[entry setMarked:[[dictEntry objectForKey:@"marked"] boolValue]];

	amount = 0;
	val = [dictEntry objectForKey:@"amount"];
	if (val != nil) amount += [(NSNumber *)val longValue];
	[entry setAmountInPennies:amount];

	[records addObject:entry];
    }

    [self sort];
    [self calculateBalance];
    [self setChanged:NO];	// Un-sets self and all entries
}

// Save this checkbook to a file. We must create something that is writable by writeToFile:atomically:, so we create a new array and add one dictionary for each checkbook entry.
- (void)saveFile:(NSString *)fileName
{
    NSEnumerator *e;
    CheckbookEntry *entry;
    NSMutableDictionary *dictEntry;
    NSMutableArray *writable = [[NSMutableArray alloc] init];

    // Translate each entry into a dictionary and add it to the writable dictionary
    for (e = [records objectEnumerator]; (entry = (CheckbookEntry *)[e nextObject]) != nil; ) {
	dictEntry = [NSMutableDictionary dictionary];
	[dictEntry setObject:[entry date] forKey:@"date"];
	[dictEntry setObject:[NSNumber numberWithInt:[entry checkNumber]] forKey:@"check_num"];
	[dictEntry setObject:[entry description] forKey:@"description"];
	[dictEntry setObject:[NSNumber numberWithLong:[entry amountInPennies]]  forKey:@"amount"];
	[dictEntry setObject:[NSNumber numberWithBool:[entry isMarked]] forKey:@"marked"];
	[writable addObject:dictEntry];
    }

    [writable writeToFile:fileName atomically:YES];
    [writable release];

    [self setChanged:NO];
}

@end
