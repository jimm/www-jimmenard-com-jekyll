// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import <Foundation/Foundation.h>


@interface CheckbookEntry : NSObject {
    NSCalendarDate *date;
    int checkNumber;
    NSConstantString *description;
    long amountInPennies;
    BOOL marked;
    BOOL changed;
}

- init;					// Designated initializer
- (void)dealloc;			// I'm free!

// Returns YES if this entry matches the template. Used by the checkbook when performing a find.
- (BOOL)matches:(CheckbookEntry *)template;

- (NSCalendarDate *)date;
- (void)setDate:(NSCalendarDate *)aDate;

- (int)checkNumber;
- (void)setCheckNumber:(int)anInt;

- (NSConstantString *)description;
- (void)setDescription:(NSConstantString *)aString;

- (float)amount;
- (long)amountInPennies;
- (void)setAmount:(float)aFloat;
- (void)setAmountInPennies:(long)aLong;

- (BOOL)isMarked;
- (void)setMarked:(BOOL)aBool;

- (BOOL)isChanged;
- (void)setChanged:(BOOL)aBool;
@end
