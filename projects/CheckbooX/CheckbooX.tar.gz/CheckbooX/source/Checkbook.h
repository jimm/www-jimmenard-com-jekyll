// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import <Cocoa/Cocoa.h>

@class CheckbookEntry;

@interface Checkbook : NSObject
{
    NSMutableArray *records;
    long balanceInPennies;
    long markedBalanceInPennies;
    BOOL changed;
    BOOL firstNewEntry;
}

- init;					// Designated initializer
- (void)dealloc;			// I'm free!

// Creates a new CheckbookEntry, adds it to the end of the list, and returns it.
- (CheckbookEntry *)addNewEntry;
- (void)sort;				// Sorts by date and check number
- (void)calculateBalance;		// Recalculates total balance and marked balance

- (float)balance;			// Returns total balance
- (float)markedBalance;			// Returns balance of marked entries

- (BOOL)isChanged;			// Returns YES if this checkbook or any entries are changed
- (void)setChanged:(BOOL)aBool;		// Sets changed flag. If NO, clears flags of all entries.

- (int)entryCount;			// Returns the number of checkbook entries.
- (int)unmarkedEntryCount;              // Returns the number of unmarked entries.
- (CheckbookEntry *)entryAt:(int)index; // Returns the specified entry.
- (CheckbookEntry *)unmarkedEntryAt:(int)index; // Returns the specified unmarked entry, skipping over marked entries.

- (void)toggleItemMarkAt:(int)index;    // Toggles the marked attribute of the item at index

// Returns the first checkbook entry matching a template whose index is >= the specified index.
- (int)findLike:(CheckbookEntry *)template from:(int)rowIndex;
// Returns the first checkbook entry matching a template whose index is <= the specified index.
// (Should that perhaps be < the index instead?)
- (int)findPreviousLike:(CheckbookEntry *)template from:(int)rowIndex;

- (void)openFile:(NSString *)fileName;	// Reads a checkbook file
- (void)saveFile:(NSString *)fileName;	// Saves to a checkbook file

@end
