// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import "TestWithAnswers.h"

@class Checkbook;
@class CheckbookEntry;

@interface TestFind : TestWithAnswers
{
    Checkbook *checkbook;
    CheckbookEntry *template;
}

// Note that you don't have to declare your test methods here.

@end
