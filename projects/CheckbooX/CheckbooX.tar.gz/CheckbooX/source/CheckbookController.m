// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import "CheckbookController.h"
#import "Checkbook.h"
#import "CheckbookEntry.h"

#define DEFAULT_CHECKBOOK_FILE @"checkbook.xml"
#define FRAME_AUTOSAVE_NAME @"CheckbookWin"

@interface CheckbookController (Private)
- (void)saveFile:file;
- (int)rowsToDisplayCount;
@end

@implementation CheckbookController

- init
{
    self = [super init];
    if (self != nil)
        displayMarkedItems = YES;
    return self;
}

- (void)dealloc
{
    [filename release];
    [super dealloc];
}

- (IBAction)add:(id)sender
{
    int newRowIndex;

    [checkbook addNewEntry];
    // Since the amount of the new entry is 0, we don't need to update
    // the balance field.
    // [balance setFloatValue:[checkbook balance]];

    [table reloadData];
    newRowIndex = [self rowsToDisplayCount] - 1;
    [table selectRow:newRowIndex byExtendingSelection:NO];
    [table scrollRowToVisible:newRowIndex];
    [table editColumn:0 row:newRowIndex withEvent:nil select:YES];
}

- (IBAction)new:(id)sender
{
}

- (IBAction)open:(id)sender
{
    int result;
//    NSArray *fileTypes = [NSArray arrayWithObject:@"td"];
    NSOpenPanel *oPanel = [NSOpenPanel openPanel];
    [oPanel setAllowsMultipleSelection:NO];
    result = [oPanel runModalForDirectory:NSHomeDirectory() file:nil  types:nil /*fileTypes*/];
    if (result == NSOKButton) {
	NSArray *filesToOpen = [oPanel filenames];
	filename = [[filesToOpen objectAtIndex:0] retain];
	[(Checkbook *)checkbook openFile:filename];

	[table reloadData];
	[balance setFloatValue:[checkbook balance]];
    }
}

- (IBAction)revert:(id)sender
{
    if (filename != nil) {
	[(Checkbook *)checkbook openFile:filename];

	[table reloadData];
	[balance setFloatValue:[checkbook balance]];
    }
}

- (IBAction)save:(id)sender
{
    if (filename == nil)
	[self saveAs:sender];
    else
	[self saveFile:filename];
}

- (IBAction)saveAs:(id)sender
{
    int runResult;
    NSSavePanel *sp = [NSSavePanel savePanel];

    /* set up new attributes */
    [sp setRequiredFileType:@"xml"];
    /* display the NSSavePanel */
    runResult = [sp runModalForDirectory:NSHomeDirectory() file:DEFAULT_CHECKBOOK_FILE];
    /* if successful, save file under designated name */
    if (runResult == NSOKButton)
	[self saveFile:[sp filename]];
}

- (IBAction)showMarkedBalance:(id)sender
{
    if ([markedBalancesCheckbox state] > 0)
	[balance setFloatValue:[checkbook markedBalance]];
    else
	[balance setFloatValue:[checkbook balance]];
}

- (IBAction)sort:(id)sender
{
    [checkbook sort];
    [table reloadData];
}

- (IBAction)toggleDisplayMarkedItems:(id)sender
{
    displayMarkedItems = !displayMarkedItems;

    NSString *title;
    if (displayMarkedItems)
        title = NSLocalizedStringFromTable(@"Hide Checkmarked", @"", @"Hide Checkmarked menu item text");
    else
        title = NSLocalizedStringFromTable(@"Show Checkmarked", @"", @"Show Checkmarked menu item text");
    [toggleShowCheckmarkedMenuItem setTitle:title];

    [table reloadData];
}

- (IBAction)toggleItemMark:(id)sender
{
    int rowIndex = [table selectedRow];
    if (rowIndex != -1) {
        [checkbook toggleItemMarkAt:rowIndex];
        NSLog(@"toggleItemMark: reloading data");
        [table reloadData];
    }
}

- (void)selectRow:(int)rowIndex
{
    [table selectRow:rowIndex byExtendingSelection:NO];
    [table scrollRowToVisible:rowIndex];
}

// Auto-position window, open default checkbook file, and scroll to the last row.
- (void)awakeFromNib
{
    int lastRowIndex;
    
    [NSApp setDelegate:self];

    // Position window based on auto-saved frame
    [[self window] setFrameUsingName:FRAME_AUTOSAVE_NAME];
    [[self window] setFrameAutosaveName:FRAME_AUTOSAVE_NAME];
    
    // Open default checkbook file
    filename = [[NSUserDefaults standardUserDefaults] stringForKey:@"CheckbookFile"];
    if (filename != nil) {
	[filename retain];
	[(Checkbook *)checkbook openFile:filename];
	[table reloadData];
	[balance setFloatValue:[checkbook balance]];
    }
    
    // Scroll to last row
    lastRowIndex = [self rowsToDisplayCount] - 1;
    if (lastRowIndex >= 0)
	[table scrollRowToVisible:lastRowIndex];
}

- (BOOL)windowShouldClose:(NSWindow *)sender
{
    int answer;

    if (windowClosed || ![checkbook isChanged])
	return YES;

    answer = NSRunAlertPanel(@"Close", @"Save first?", @"Save", @"Don't Save", @"Cancel");
    switch (answer) {
	case NSAlertDefaultReturn:
	    [self save:sender];
	    return YES;
	case NSAlertAlternateReturn:
	    return YES;
	case NSAlertOtherReturn:
	default:
	    return NO;
    }
}

- (void)windowWillClose:(NSNotification *)notification
{
    windowClosed = YES;
}

- (NSApplicationTerminateReply)applicationShouldTerminate:(id)sender
{
    if (windowClosed)
	return NSTerminateNow;
    return [self windowShouldClose:sender] ? NSTerminateNow : NSTerminateCancel;
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender {
    return YES;
}

@end

@implementation CheckbookController (TableDataSource)

- (int)numberOfRowsInTableView:(NSTableView *)aTableView
{
    return [self rowsToDisplayCount];
}

- (id)tableView:(NSTableView *)aTableView
objectValueForTableColumn:(NSTableColumn *)aTableColumn
			  row:(int)rowIndex
{
    CheckbookEntry *entry;
    NSConstantString *identifier;

    NSParameterAssert(rowIndex >= 0 && rowIndex < [self rowsToDisplayCount]);
    entry = displayMarkedItems ? [checkbook entryAt:rowIndex] : [checkbook unmarkedEntryAt:rowIndex];
    identifier = [aTableColumn identifier];

    if ([identifier compare:@"date"] == NSOrderedSame)
	return [entry date];
    else if ([identifier compare:@"check_num"] == NSOrderedSame) {
	if ([entry checkNumber] == 0)
	    return nil;
	else
	    return [NSNumber numberWithInt:[entry checkNumber]];
    }
    else if ([identifier compare:@"description"] == NSOrderedSame)
	return [entry description];
    else if ([identifier compare:@"deposit"] == NSOrderedSame) {
	if ([entry amount] > 0)
	    return [NSNumber numberWithFloat:[entry amount]];
	else
	    return nil;
    }
    else if ([identifier compare:@"withdrawal"] == NSOrderedSame) {
	if ([entry amount] < 0)
	    return [NSNumber numberWithFloat:-[entry amount]];
	else
	    return nil;
    }
    else if ([identifier compare:@"marked"] == NSOrderedSame)
	return [NSNumber numberWithBool:[entry isMarked]];
    else
	return nil;
}

- (void)tableView:(NSTableView *)aTableView
   setObjectValue:anObject
   forTableColumn:(NSTableColumn *)aTableColumn
			    row:(int)rowIndex
{
    NSConstantString *identifier;
    CheckbookEntry *entry;
    NSString *str;

    NSParameterAssert(rowIndex >= 0 && rowIndex < [self rowsToDisplayCount]);
    entry = displayMarkedItems ? [checkbook entryAt:rowIndex] : [checkbook unmarkedEntryAt:rowIndex];
    identifier = [aTableColumn identifier];

    if ([identifier compare:@"date"] == NSOrderedSame)
	[entry setDate:anObject];
    else if ([identifier compare:@"check_num"] == NSOrderedSame)
	[entry setCheckNumber:[anObject intValue]];
    else if ([identifier compare:@"description"] == NSOrderedSame)
	[entry setDescription:anObject];
    else if ([identifier compare:@"deposit"] == NSOrderedSame) {
	str = [anObject stringValue];
	if (str != nil && [str length] > 0)
	    [entry setAmount:[anObject floatValue]];
    }
    else if ([identifier compare:@"withdrawal"] == NSOrderedSame) {
	str = [anObject stringValue];
	if (str != nil && [str length] > 0)
	    [entry setAmount:-[anObject floatValue]];
    }
    else if ([identifier compare:@"marked"] == NSOrderedSame)
	[entry setMarked:[anObject boolValue]];
    
    if ([identifier compare:@"deposit"] == NSOrderedSame
	     || [identifier compare:@"withdrawal"] == NSOrderedSame
	     || [identifier compare:@"marked"] == NSOrderedSame) {
	[checkbook calculateBalance];
	[self showMarkedBalance:nil];
    }
}

@end

@implementation CheckbookController (Private)

- (void)saveFile:file
{
    if (file != filename) {
        [filename release];
	filename = file;
	[filename retain];
    }
    
    // Save file name to defaults database
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:file forKey:@"CheckbookFile"];

    [checkbook saveFile:filename];
}

- (int)rowsToDisplayCount {
    if (displayMarkedItems)
        return [checkbook entryCount];
    else
        return [checkbook unmarkedEntryCount];
}

@end
