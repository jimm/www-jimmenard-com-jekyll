// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import "TestFind.h"
#import "Checkbook.h"
#import "CheckbookEntry.h"

// Can anyone help me make this a relative path instead of an absolute path?
#define TEST_CHECKBOOK_FILE @"~/projects/CheckbooX/test_checkbook.xml"
#define TEST_ANSWERS_FILE @"~/projects/CheckbooX/test_find_answers.xml"

#define NOT_FOUND -1

@implementation TestFind

- (void) setUp {
    checkbook = [[Checkbook alloc] init];
    [checkbook openFile:[TEST_CHECKBOOK_FILE stringByExpandingTildeInPath]];
    [self readAnswersFrom:[TEST_ANSWERS_FILE stringByExpandingTildeInPath]];

    template = [[CheckbookEntry alloc] init];
    // "Erase" default date and description
    [template setDate:nil];
    [template setDescription:nil];
}

- (void) tearDown {
    [checkbook release];
    [template release];
}

- (void) testFindByDescription {
    NSConstantString *desc = (NSConstantString *)[self answerAsString:@"findDescription"];
    [template setDescription:desc];
    int index = [checkbook findLike:template from:0];
    STAssertEquals([self answerAsInt:@"findDescriptionIndex"], index, nil);
    CheckbookEntry *found = [checkbook entryAt:index];
    STAssertNotNil(found, nil);
    STAssertEqualObjects(desc, [found description], nil);
    
    // There is no other entry with the same description. Let's look for the next one; we should get back NOT_FOUND.
    index = [checkbook findLike:template from:index+1];
    STAssertEquals(NOT_FOUND, index, nil);
}

- (void) testFindByAmount {
    [template setAmountInPennies:[self answerAsInt:@"100WithdrawalAmountInPennies"]];
    int index = [checkbook findLike:template from:0];
    STAssertEquals([self answerAsInt:@"first100WithdrawalIndex"], index, nil);
    index = [checkbook findLike:template from:index+1];
    STAssertEquals([self answerAsInt:@"second100WithdrawalIndex"], index, nil);
    index = [checkbook findLike:template from:index+1];
    STAssertEquals(NOT_FOUND, index, nil);
}

- (void) testFindByDate {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] initWithDateFormat:@"%m/%d/%y" allowNaturalLanguage:NO];
    NSCalendarDate *templateDate;
    BOOL conversionResult;
    NSString *error;
    
    conversionResult = [dateFormatter getObjectValue:&templateDate forString:[self answerAsString:@"startBalanceDateString"] errorDescription:&error];
    STAssertEquals(YES, conversionResult, error);

    [template setDate:templateDate];

    // Find this entry and compare it with the first entry (which is the one we looked for). These tests are a bit redundant (for example, checking that the indexes match and also checking that the entries at those indexes are the same), but what the heck.
    int index = [checkbook findLike:template from:0];
    STAssertEquals([self answerAsInt:@"startBalanceIndex"], index, nil);
    CheckbookEntry *found = [checkbook entryAt:index];
    STAssertNotNil(found, nil);
    CheckbookEntry *entry = [checkbook entryAt:0];
    STAssertEqualObjects(found, entry, nil);
    
    // Unlike other matches which are exact, date matches return YES if the entry date is >= the template date.
    int i, numEntries = [self answerAsInt:@"numEntries"];
    for (i = index + 1; i < numEntries; ++i) {
        index = [checkbook findLike:template from:i];
        STAssertEquals(i, index, nil);
    }
    
    // Try looking past the end of the 
    index = [checkbook findLike:template from:numEntries];
    STAssertEquals(NOT_FOUND, index, nil);
}

@end
