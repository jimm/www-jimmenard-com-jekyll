// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import "TestCheckbook.h"
#import "Checkbook.h"
#import "CheckbookEntry.h"

// Can anyone help me make this a relative path instead of an absolute path?
#define TEST_CHECKBOOK_FILE @"~/projects/CheckbooX/test_checkbook.xml"
#define TEST_ANSWERS_FILE @"~/projects/CheckbooX/test_checkbook_answers.xml"

@implementation TestCheckbook

- (void) setUp {
    checkbook = [[Checkbook alloc] init];
    [checkbook openFile:[TEST_CHECKBOOK_FILE stringByExpandingTildeInPath]];
    [self readAnswersFrom:[TEST_ANSWERS_FILE stringByExpandingTildeInPath]];
}

- (void) tearDown {
    [checkbook release];
}

- (void) testNumEntries {
    // DEBUG: make sure the test answer file is being read correctly
    STAssertEquals(5, [self answerAsInt:@"numEntries"], nil); // DEBUG

    STAssertEquals([self answerAsInt:@"numEntries"], [checkbook entryCount], nil);
}

- (void) testNumUnmarkedEntries {
    STAssertEquals([self answerAsInt:@"numUnmarkedEntries"], [checkbook unmarkedEntryCount], nil);
}

- (void) testAddEntry {
    int numEntries = [self answerAsInt:@"numEntries"];
    [checkbook addNewEntry];
    STAssertEquals(numEntries + 1, [checkbook entryCount], nil);
}

- (void) testNewCheckbookBalance {
    [checkbook release];
    checkbook = [[Checkbook alloc] init];
    STAssertEquals(0.0f, [checkbook balance], nil);
    STAssertEquals(0.0f, [checkbook markedBalance], nil);
}

- (void) testBalance {
    STAssertEquals([self answerAsFloat:@"balance"], [checkbook balance], nil);
    STAssertEquals([self answerAsFloat:@"markedBalance"], [checkbook markedBalance], nil);
}

- (void) testEntryAt {
    CheckbookEntry *entry = [checkbook entryAt:0];
    STAssertNotNil(entry, nil);
    STAssertEqualObjects([self answerAsString:@"entryAt0Description"], [entry description], nil);

    entry = [checkbook unmarkedEntryAt:0];
    STAssertNotNil(entry, nil);
    STAssertEqualObjects([self answerAsString:@"unmarkedEntryAt0Description"], [entry description], nil);
}

- (void) testSort {
    // Add a new entry to the checkbook. Set its date to be as early as possible.
    CheckbookEntry *entry = [checkbook addNewEntry];
    [entry setDescription:@"Earliest Checkbook Entry"];
    [entry setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    
    [checkbook sort];
    STAssertEqualObjects(@"Earliest Checkbook Entry", [[checkbook entryAt:0] description], nil);
}

@end
