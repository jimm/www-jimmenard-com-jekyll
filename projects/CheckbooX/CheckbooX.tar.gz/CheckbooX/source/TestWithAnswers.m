// Copyright (c) 2003-2004 Jim Menard, jimm@io.com
// Released under the Apache Software License. See CheckbooX Readme.rtf for details.

#import "TestWithAnswers.h"

@implementation TestWithAnswers

-(void)dealloc {
    [answers release];
    [super dealloc];
}

-(void)readAnswersFrom:(NSString *)filePath {
    NSArray *contents = [NSArray arrayWithContentsOfFile:filePath];
    STAssertNotNil(contents, filePath);
    NSEnumerator *e = [contents objectEnumerator];
    STAssertNotNil(e, filePath);
    answers = [(NSDictionary *)[e nextObject] retain];
    STAssertNotNil(answers, filePath);
}

-(NSString *)answerAsString:(NSString *)answerName {
    return [answers objectForKey:answerName];
}

-(int)answerAsInt:(NSString *)answerName {
    return [[answers objectForKey:answerName] intValue];
}

-(long)answerAsLong:(NSString *)answerName {
    return [[answers objectForKey:answerName] longValue];
}

-(float)answerAsFloat:(NSString *)answerName {
    return [[answers objectForKey:answerName] floatValue];
}

-(BOOL)answerAsBool:(NSString *)answerName {
    return [[answers objectForKey:answerName] boolValue];
}

@end
