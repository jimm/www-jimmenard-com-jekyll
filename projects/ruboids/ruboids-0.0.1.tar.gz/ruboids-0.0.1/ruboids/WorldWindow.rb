#
# Copyright (c) 2001 by Jim Menard <jimm@io.com>
#
# Released under the same license as Ruby. See
# http://www.ruby-lang.org/en/LICENSE.txt.
#

require 'qt'
require 'Canvas'
require 'CameraDialog'

class WorldWindow < QMainWindow

    MENU_CAMERA_DIALOG = 1

    attr_accessor :canvas

    def initialize
	super
	setCaption("Boids")
	vLayout = QVBoxLayout.new(self, 0, 0, "vLayout")
	mbar = setupMenubar()
	vLayout.setMenuBar(mbar)

	@canvas = Canvas.new(self)
	vLayout.addWidget(@canvas)

	vLayout.activate()
	setCentralWidget(@canvas)
	setGeometry(0, 0, $PARAMS['window_width'],
		    $PARAMS['window_height'])
    end

    def setupMenubar
	# Create menu bar
	mbar = QMenuBar.new(self)

	# Create and populate file menu
	menu = QPopupMenu.new()
	menu.insertItemQObj("Exit", QApplication::qApp, QSLOT("quit()"),
			    CTRL+Key_Q)

	# Add file menu to menu bar
	mbar.insertItem("&File", menu)

	# Create and populate options menu
	menu = QPopupMenu.new()
	menu.insertItem("&Camera...", MENU_CAMERA_DIALOG, -1)

	# Add options menu to menu bar and link it to method below
	mbar.insertItem("&Options", menu)
	Qt::connect(menu, QSIGNAL("activated(int)"), self, 'slotMenuActivated')

	return mbar
    end

    def slotMenuActivated(id)
	if id == MENU_CAMERA_DIALOG
	    CameraDialog.new(nil).exec()
	end
    end
end
