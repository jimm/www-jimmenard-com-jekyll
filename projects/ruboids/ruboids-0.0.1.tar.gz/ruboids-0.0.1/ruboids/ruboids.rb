#! /usr/bin/env ruby
#
# Copyright (c) 2001 by Jim Menard <jimm@io.com>
#
# Released under the same license as Ruby. See
# http://www.ruby-lang.org/en/LICENSE.txt.
#

require 'qt'
require 'qgl'
require 'World'
require 'WorldWindow'
require 'Canvas'
require 'Params'

app = QApplication.new([$0] + ARGV)
if (!QGLFormat::hasOpenGL())
    warning("This system has no OpenGL support. Exiting.")
    exit -1
end

Params.readParamsFromFile(ARGV[0] || 'boids.properties')
world = World.instance()	# Force creation

win = WorldWindow.new()
app.setMainWidget(win)

world.canvas = win.canvas
win.show()
world.start()
app.exec()
