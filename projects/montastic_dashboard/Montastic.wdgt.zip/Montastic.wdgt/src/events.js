/*
events.js -- home of javascript gone wild!
          -- Joshua Emmons (skia.net) 
	  -- Nov/16/05

This license intentionally left blank. COPY IT! STEAL IT! MAKE IT YOUR OWN!

[I've done just that: I've removed everything but what Montastic.wdgt needs.
 -- jimm]
*/

function showEyeBack() {
  document.getElementById('eyeBack').style.display = "block";
}

function hideEyeBack() {
  document.getElementById('eyeBack').style.display = "none";
}


