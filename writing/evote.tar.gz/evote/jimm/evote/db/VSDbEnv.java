package jimm.evote.db;
import jimm.evote.ErrorHandler;
import com.sleepycat.je.*;
import java.io.File;

/**
 * Handles setup and teardown of the database environment and databases.
 * This includes creating the databases and secondary databases.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class VSDbEnv {

/** Name of {@link jimm.evote.Booth} primary database. */
protected static final String BOOTH_DATABASE = "booths";
/** Name of {@link jimm.evote.Vote} primary database. */
protected static final String VOTE_DATABASE = "votes";
/**
 * Name of {@link jimm.evote.Booth} secondary database; the key is the state.
 */
protected static final String BOOTH_STATE_INDEX = "booths_by_state";
/**
 * Name of {@link jimm.evote.Vote} secondary database; the key is the race id.
 */
protected static final String VOTE_RACE_INDEX = "votes_by_race";
/**
 * Name of {@link jimm.evote.Vote} secondary database; the key is the race id
 * plus the party id.
 */
protected static final String VOTE_RACE_AND_PARTY_INDEX =
    "votes_by_race_and_party";

protected Environment dbEnvironment;
protected Database boothDb;
protected Database voteDb;
protected SecondaryDatabase boothByStateDb;
protected SecondaryDatabase voteByRaceDb;
protected SecondaryDatabase voteByRaceAndPartyDb;

public VSDbEnv(String databaseDirectory, boolean readOnly) {
    openEnvironment(databaseDirectory, readOnly);
    openDatabases(readOnly);
}

private void openEnvironment(String databaseDirectory, boolean readOnly) {
    EnvironmentConfig config = new EnvironmentConfig();
    config.setAllowCreate(!readOnly);
    config.setTransactional(!readOnly);
    try {
	File dir = new File(databaseDirectory);
	if (!dir.exists()) {
	    if (readOnly) {	// Don't create database if read-only
		ErrorHandler.error("Database directory " + databaseDirectory
				   + " does not exist;\nit will not be created"
				   + " because the read-only flag is set",
				   true);
	    }
	    if (!dir.mkdirs()) {
		ErrorHandler.error("Database directory " + databaseDirectory
				   + " does not exist;\nan attempt to create"
				   + " it failed",
				   true);
	    }
	}

	dbEnvironment = new Environment(dir, config);
    }
    catch (DatabaseException dbe) {
	ErrorHandler.error("openEnvironment", dbe, true);
    }
}

private void openDatabases(boolean readOnly) {
    boothDb = openDatabase(readOnly, BOOTH_DATABASE);
    voteDb = openDatabase(readOnly, VOTE_DATABASE);

    boothByStateDb =
	openSecondaryDatabase(readOnly, BOOTH_STATE_INDEX, boothDb,
			      new BoothStateKeyCreator());

    voteByRaceDb =
	openSecondaryDatabase(readOnly, VOTE_RACE_INDEX, voteDb,
			      new VoteRaceKeyCreator());

    voteByRaceAndPartyDb =
	openSecondaryDatabase(readOnly, VOTE_RACE_AND_PARTY_INDEX, voteDb,
			      new VoteRacePartyKeyCreator());
}

private Database openDatabase(boolean readOnly, String databaseName) {
    DatabaseConfig config = new DatabaseConfig();
    config.setAllowCreate(!readOnly);
    config.setTransactional(!readOnly);
    Database db = null;
    try {
	// If readOnly is false, then the database config specifies that we
	// can use transactions. When opening the database, the first argument
	// is an optional transaction. If that argument is null and readOnly
	// is false (transactional is true), then autocommit is in effect for
	// this operation.
	db = dbEnvironment.openDatabase(null, databaseName, config);
    }
    catch (DatabaseException dbe) {
	ErrorHandler.error("openDatabase", dbe, true);
    }
    return db;
}

private SecondaryDatabase openSecondaryDatabase(boolean readOnly,
						String indexName,
						Database primaryDb,
						SecondaryKeyCreator kc)
{
    SecondaryConfig config = new SecondaryConfig();
    config.setAllowCreate(!readOnly);
    config.setTransactional(!readOnly);
    config.setAllowPopulate(!readOnly);
    config.setKeyCreator(kc);
    // We need to allow duplicates for all our secondary databases
    config.setSortedDuplicates(true);

    SecondaryDatabase db = null;
    try {
	db = dbEnvironment
	    .openSecondaryDatabase(null, indexName, primaryDb, config);
    }
    catch (DatabaseException dbe) {
	ErrorHandler.error("openSecondaryDatabase", dbe, true);
    }
    return db;
}
					       
public Environment getEnv() { return dbEnvironment; }
public Database getBoothDb() { return boothDb; }
public SecondaryDatabase getBoothByStateDb() { return boothByStateDb; }
public Database getVoteDb() { return voteDb; }
public SecondaryDatabase getVoteByRaceDb() { return voteByRaceDb; }
public SecondaryDatabase getVoteByRaceAndPartyDb() {
    return voteByRaceAndPartyDb;
}

public void shutDown() {
    try {
	// Must close secondary databases before closing primary databases
	if (voteByRaceDb != null)
	    voteByRaceDb.close();
	if (voteByRaceAndPartyDb != null)
	    voteByRaceAndPartyDb.close();
	if (boothByStateDb != null)
	    boothByStateDb.close();

	// Close database
	if (boothDb != null)
	    boothDb.close();
	if (voteDb != null)
	    voteDb.close();

	// Close environment
	if (dbEnvironment != null)
	    dbEnvironment.close();
    }
    catch (DatabaseException dbe) {
	ErrorHandler.error("shutDown", dbe, true);
    }
    finally {
	voteByRaceDb = null;
	boothDb = null;
	voteDb = null;
	dbEnvironment = null;
    }
}

}
