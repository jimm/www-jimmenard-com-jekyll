package jimm.evote.db;
import jimm.evote.Vote;
import com.sleepycat.bind.tuple.*;
import java.io.IOException;

/**
 * Translates {@link Vote}s to and from storage format.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class VoteBinding extends TupleBinding {

public void objectToEntry(Object object, TupleOutput to) {
    Vote vote = (Vote)object;
    to.writeString(vote.key);
    // Order of fields determines sort order
    for (int i = 0; i < 4; ++i)
	to.writeByte(vote.boothAddress[i]);
    to.writeInt(vote.voteNum);
    to.writeInt(vote.voteBlockId);
    to.writeInt(vote.race);
    to.writeInt(vote.candidateID);
    to.writeInt(vote.candidateParty);
}

public Object entryToObject(TupleInput ti) {
    String key = ti.readString();

    byte[] boothAddress = new byte[4];
    for (int i = 0; i < 4; ++i)
	boothAddress[i] = ti.readByte();

    // Assumes order of ctor args is same as order written in objectToEntry
    return new Vote(boothAddress, ti.readInt(), ti.readInt(), ti.readInt(),
		    ti.readInt(), ti.readInt());
}

}
