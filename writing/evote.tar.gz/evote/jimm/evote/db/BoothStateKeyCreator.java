package jimm.evote.db;
import jimm.evote.Booth;
import java.io.IOException;
import com.sleepycat.je.*;
import com.sleepycat.bind.tuple.TupleBinding;

/**
 * Creates secondary booth database keys where the state is the key.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class BoothStateKeyCreator implements SecondaryKeyCreator {

protected TupleBinding dataBinding;

public BoothStateKeyCreator() {
    dataBinding = new BoothBinding();
}

public boolean createSecondaryKey(SecondaryDatabase db,
				  DatabaseEntry keyEntry,
				  DatabaseEntry dataEntry,
				  DatabaseEntry resultEntry)
    throws DatabaseException
{
    if (dataEntry == null)
	throw new DatabaseException("Missing primary record data in"
				    + " BoothStateKeyCreator");

    try {
	// Convert DatabaseEntry to a Booth and use the state from it.
	Booth booth = (Booth)dataBinding.entryToObject(dataEntry);
	resultEntry.setData(booth.state.getBytes("UTF-8"));
    }
    catch (IOException ioe) {
	throw new DatabaseException(ioe);
    }
    return true;
}

}
