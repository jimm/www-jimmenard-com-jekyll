package jimm.evote.db;
import jimm.evote.Vote;
import jimm.evote.Util;
import java.io.IOException;
import com.sleepycat.je.*;
import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.bind.tuple.IntegerBinding;	// DEBUG

/**
 * Creates secondary vote database keys where the race is the key.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class VoteRaceKeyCreator implements SecondaryKeyCreator {

protected TupleBinding dataBinding;

public VoteRaceKeyCreator() {
    dataBinding = new VoteBinding();
}

public boolean createSecondaryKey(SecondaryDatabase db,
				  DatabaseEntry keyEntry,
				  DatabaseEntry dataEntry,
				  DatabaseEntry resultEntry)
    throws DatabaseException
{
    if (dataEntry == null)
	throw new DatabaseException("Missing primary record data in"
				    + " VoteRaceKeyCreator");

    // Convert DatabaseEntry to a Vote and use the race from it.
    Vote vote = (Vote)dataBinding.entryToObject(dataEntry);
    IntegerBinding.intToEntry(vote.race, resultEntry);

    return true;
}

}
