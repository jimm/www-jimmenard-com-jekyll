package jimm.evote.db;
import jimm.evote.Vote;
import java.io.IOException;
import com.sleepycat.je.*;
import com.sleepycat.bind.tuple.TupleBinding;

/**
 * Creates secondary vote database keys where the key = race + party.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class VoteRacePartyKeyCreator implements SecondaryKeyCreator {

protected TupleBinding dataBinding;

public VoteRacePartyKeyCreator() {
    dataBinding = new VoteBinding();
}

public boolean createSecondaryKey(SecondaryDatabase db,
				  DatabaseEntry keyEntry,
				  DatabaseEntry dataEntry,
				  DatabaseEntry resultEntry)
    throws DatabaseException
{
    if (dataEntry == null)
	throw new DatabaseException("Missing primary record data in"
				    + " VoteRacePartyKeyCreator");

    try {
	// Convert DatabaseEntry to a Vote and use the race and party from it.
	Vote vote = (Vote)dataBinding.entryToObject(dataEntry);
	String key = "" + vote.race + ':' + vote.candidateParty;
	resultEntry.setData(key.getBytes("UTF-8"));
    }
    catch (IOException ioe) {
	throw new DatabaseException(ioe);
    }
    return true;
}

}
