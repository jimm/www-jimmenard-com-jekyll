package jimm.evote.db;
import jimm.evote.Booth;
import com.sleepycat.bind.tuple.*;
import java.io.IOException;

/**
 * Translates {@link Booth}s to and from storage format.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class BoothBinding extends TupleBinding {

public void objectToEntry(Object object, TupleOutput to) {
    Booth booth = (Booth)object;
    for (int i = 0; i < 4; ++i)
	to.writeByte(booth.address[i]);
    to.writeString(booth.state);
    to.writeString(booth.city);
    to.writeString(booth.district);
}

public Object entryToObject(TupleInput ti) {
    byte[] address = new byte[4];
    for (int i = 0; i < 4; ++i)
	address[i] = ti.readByte();
    return new Booth(address, ti.readString(), ti.readString(),
		     ti.readString());
}

}
