package jimm.evote;
import jimm.evote.*;
import java.util.*;

/**
 * A voting booth.
 * <p>
 * Instead of writing accessor methods, I've made the ivars public.
 * <code>Booth</code>s are essentially simple data structures.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class Booth {

/** The voting booth's identifier is its IP address. */
public byte[] address;
/** The two-letter abbreviation of the US state this booth is in. */
public String state;
/** City name. */
public String city;
/** District name. */
public String district;
/** Votes. */
public List votes;

public Booth(byte[] address, String state, String city, String district) {
    this.address = address;
    this.state = state;
    this.city = city;
    this.district = district;
}

/**
 * Generates simulated votes and sends them to <var>server</var>. We
 * decide randomly which races to vote in.
 *
 * @param server a vote server
 */
public void generateAndSendVotesTo(VoteServer server) {
    Random rand = new Random();
    int numVoters = Util.intParam("min_voters_per_booth")
	+ rand.nextInt(Util.intParam("max_voters_per_booth")
		       - Util.intParam("min_voters_per_booth"));
    // Initially allocate the average size of the list.
    votes = new ArrayList(numVoters * (Vote.NUM_RACES / 2));

    int voteNum = 0;
    for (int voterNum = 0; voterNum < numVoters; ++voterNum) {
	for (int race = 0; race < Vote.NUM_RACES; ++race) {
	    if (rand.nextBoolean()) { // Randomly decide which races to vote on
		int party = rand.nextInt(Vote.NUM_PARTIES);
		// To simplify things, the candidate id is always the same
		// as the party id.
		votes.add(new Vote(address, voteNum, voterNum, race, party,
				   party));
		++voteNum;
	    }
	}
    }

    // If we were really running over a network connection, here is where we
    // would send the votes to the server. Instead, we can talk to the server
    // directly.
    server.acceptVotesAtomically(this);
    votes = null;
}

public String toString() {
    return "[Booth address=" + Util.quadToString(address)
	+ ", state=" + state + ", city=" + city
	+ ", district=" + district + "]";
}

}
