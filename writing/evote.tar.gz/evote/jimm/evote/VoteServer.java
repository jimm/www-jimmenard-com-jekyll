package jimm.evote;
import jimm.evote.db.*;
import com.sleepycat.je.*;
import com.sleepycat.bind.ByteArrayBinding;
import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.bind.tuple.IntegerBinding;
import com.sleepycat.collections.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * Stores {@link Vote}s that come from {@link Booth}s and runs a few
 * hard-coded queries.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class VoteServer {

/** Manages database housekeeping. */
protected VSDbEnv dbEnvironment;

/**
 * Opens the databases read-write.
 * 
 * @param databaseDirectory path to the database directory
 */
public VoteServer(String databaseDirectory) {
    this(databaseDirectory, false);
}

/**
 * Opens the databases. If we are going to write to the databases and they
 * do not yet exist, they are created.
 * 
 * @param databaseDirectory path to the database directory
 * @param readOnly if <code>true</code>, databases will be opened read-only
 */
public VoteServer(String databaseDirectory, boolean readOnly) {
    dbEnvironment = new VSDbEnv(databaseDirectory, readOnly);
}

/**
 * Gracefully shuts down the databases.
 */
public void shutDown() {
    dbEnvironment.shutDown();
}

/**
 * Accepts the votes from a voting booth.
 * <p>
 * This method must be thread safe, not because the transactions require it
 * but because {@link ElectionDay} uses multiple threads when it tells booths
 * to send votes to the server. Being thread safe does <em>not</em> mean it
 * has to be synchronized, nor do we have to worry about using
 * <var>dbEnvironment</var> safely because the objects it holds (environment,
 * database) are already thread safe.
 *
 * @param booth a voting booth ripe with votes
 */
public void acceptVotesAtomically(Booth booth) {
    Transaction txn = null;
    try {
// 	StopWatch watch = new StopWatch("storing booth and " // DEBUG
// 					+ booth.votes.size() + " votes");
// 	watch.start();		// DEBUG
	TransactionConfig config = new TransactionConfig();
	txn = dbEnvironment.getEnv().beginTransaction(null, null);
	storeBooth(txn, booth);
	for (Iterator iter = booth.votes.iterator(); iter.hasNext(); )
	    storeVote(txn, (Vote)iter.next());
	txn.commitNoSync();	// Let's live dangerously
	txn = null;
// 	watch.stop();		// DEBUG
    }
    catch (Exception e) {	// DatabaseException, IOException
	try { if (txn != null) txn.abort(); }
	catch (DatabaseException dbe2) {}
	ErrorHandler.error("acceptVotesAtomically", e);
    }
}

/**
 * Stores <var>booth</var> in the booth database. A {@link BoothBinding}
 * translates the booth into a format suitable for storage.
 *
 * @param txn a transaction; if <code>null</code> and the database is
 * transactional then autocommit is used
 * @param booth
 */
protected void storeBooth(Transaction txn, Booth booth)
    throws DatabaseException, IOException
{
    // The lookup key is the booth's IP address, which is a byte array. Since
    // the database stores byte arrays "natively", we don't have to do any
    // translation.
    DatabaseEntry key = new DatabaseEntry(booth.address);

    // A subclass of TupleBinding translates the contents of the booth into a
    // format acceptable to the database.
    DatabaseEntry data = new DatabaseEntry();
    new BoothBinding().objectToEntry(booth, data);

    dbEnvironment.getBoothDb().put(txn, key, data);
}

/**
 * Stores <var>vote</var> in the vote database.
 *
 * @param txn a transaction; if <code>null</code> and the database is
 * transactional then autocommit is used
 * @param vote a vote
 */
protected void storeVote(Transaction txn, Vote vote)
    throws DatabaseException, IOException
{
    DatabaseEntry key = new DatabaseEntry(vote.key.getBytes("UTF-8"));

    // VoteBinding is a subclass of TupleBinding. It translates the contents
    // of the vote into a format acceptable to the database.
    DatabaseEntry data = new DatabaseEntry();
    VoteBinding binding = new VoteBinding();
    binding.objectToEntry(vote, data);

    dbEnvironment.getVoteDb().put(txn, key, data);
}

/**
 * Runs a few hard-coded queries and outputs the results.
 */
public void runQueries() {
    try {
	printTotalVotes();	// Iterates over records in the database
	printSingleVote();	// Uses Database.get()
	printSingleStateBoothList(); // Uses cursor and map/iterator
	printPresidentialVotes(); // Uses map
	printPresidentialResults(); // Uses map
    }
    catch (Exception e) {
	// UnsupportedEncodingException, DatabaseException, or IOException
	ErrorHandler.error("runQueries", e);
    }
}

/**
 * Print the number of votes in the vote database.
 */
public void printTotalVotes() {
    Cursor cursor = null;
    try {
	Database db = dbEnvironment.getVoteDb();
	cursor = db.openCursor(null, null);

	DatabaseEntry foundKey = new DatabaseEntry();
	DatabaseEntry foundData = new DatabaseEntry();
	int numRecords = 0;
	while (cursor.getNext(foundKey, foundData, LockMode.DEFAULT) ==
	       OperationStatus.SUCCESS)
	    ++numRecords;
	System.out.println("There are " + numRecords
			   + " records in the vote database");
    }
    catch (DatabaseException dbe) {
	ErrorHandler.error("printTotalVotes", dbe);
    }
    finally {
	try {
	    if (cursor != null) cursor.close();
	}
	catch (DatabaseException dbe2) {}
    }
}

/**
 * Runs a query that uses a specific key to find a single record. Shows a
 * simple query that uses a key from the primary database.
 */
public void printSingleVote()
    throws UnsupportedEncodingException, DatabaseException, IOException
{
    String voteKey = "192.168.0.3:1";
    DatabaseEntry key = new DatabaseEntry(voteKey.getBytes("UTF-8"));
    DatabaseEntry data = new DatabaseEntry();

    OperationStatus status =
	dbEnvironment.getVoteDb().get(null, key, data, null);
    if (status == OperationStatus.SUCCESS) {
	Vote vote = (Vote)new VoteBinding().entryToObject(data);
	System.out.println("Single vote with key " + voteKey + " = "
			   + vote.toString());
    }
    else
	ErrorHandler.error("printSingleVote", status);
}

/**
 * Finds a state and prints the list of booths in that state. The same
 * query is run two times in two different ways: first with a cursor and
 * then with a map and iterator.
 */
public void printSingleStateBoothList()
    throws UnsupportedEncodingException, DatabaseException, IOException
{
    String state = getSomeBoothState(); // Get any booth state
    byte[] key = state.getBytes("UTF-8");

    System.out.println("Booths in " + state + " using a cursor:");
    printSingleStateBoothListUsingCursor(state, key);

    System.out.println("Booths in " + state + " using a map/iterator:");
    printSingleStateBoothListUsingIterator(state, key);
}

/**
 * Prints the booths in <var>state</var> using a cursor. Reads from the
 * secondary database that has state as key.
 */
public void printSingleStateBoothListUsingCursor(String state, byte[] key) {
    Cursor cursor = null;
    try {
	// Null transaction (first arg) means we have read-only access.
	cursor = dbEnvironment.getBoothByStateDb().openCursor(null, null);

	DatabaseEntry foundKey = new DatabaseEntry(key);
	DatabaseEntry foundData = new DatabaseEntry();
	BoothBinding binding = new BoothBinding();

	OperationStatus status =
	    cursor.getSearchKey(foundKey, foundData, null);
	while (status == OperationStatus.SUCCESS) {
	    // Cursor keeps going past selected state, so stop when we
	    // see a different state.
	    if (!state.equals(new String(foundKey.getData())))
		break;

	    System.out.println("  " + (Booth)binding.entryToObject(foundData));
	    status = cursor.getNext(foundKey, foundData, null);
	}
    }
    catch (DatabaseException dbe) {
	ErrorHandler.error("printSingleStateBoothList", dbe);
    }
    finally {
	try { if (cursor != null) cursor.close(); }
	catch (DatabaseException dbe) {}
    }
}

/**
 * Prints the booths in <var>state</var> using a map and an iterator.
 * Notice how the iterator methods don't throw database exceptions.
 */
public void printSingleStateBoothListUsingIterator(String state, byte[] key) {
    // Get a map over the vote database.
    StoredMap map = new StoredMap(dbEnvironment.getBoothByStateDb(),
				  new ByteArrayBinding(),
				  new BoothBinding(), false);

    Collection booths = map.duplicates(key);
    Iterator iter;
    for (iter = booths.iterator(); iter.hasNext(); )
	System.out.println("  " + (Booth)iter.next());

    // Database iterators must be closed. You can either call the iterator's
    // close method or use the static StoredIterator.close() convenience
    // method, which takes an Iterator. Since we decided to declare iter as an
    // Iterator instead of a StoredIterator, let's use the convenience method.
    StoredIterator.close(iter);
}

/**
 * Returns a state string. We look for a known booth and return its state.
 * We can't just return a random state because we may not have generated
 * voting booths for all states.
 */
public String getSomeBoothState() throws DatabaseException, IOException {
    byte[] addressKey = {(byte)192, (byte)168, 0, 1};
    DatabaseEntry key = new DatabaseEntry(addressKey);
    DatabaseEntry data = new DatabaseEntry();
    OperationStatus status =
	dbEnvironment.getBoothDb().get(null, key, data, null);
    if (status == OperationStatus.SUCCESS) {
	Booth booth = (Booth)new BoothBinding().entryToObject(data);
	return booth.state;
    }

    throw new DatabaseException("booth db key " + addressKey + " not found");
}

/**
 * Runs a query that prints the total number of presidential votes. Shows
 * how to create a map and find all values that match a key.
 */
public void printPresidentialVotes() throws IOException {
    // Get a map over the vote secondary database.
    StoredMap map = new StoredMap(dbEnvironment.getVoteByRaceDb(),
				  new ByteArrayBinding(), new VoteBinding(),
				  false);

    DatabaseEntry keyEntry = new DatabaseEntry();
    IntegerBinding.intToEntry(Vote.RACE_PRESIDENT, keyEntry);

    // Pass in the raw data, not the DatabaseEntry
    Collection votes = map.duplicates(keyEntry.getData());
    System.out.println("There are " + votes.size()
		       + " presidential race votes");
}

/**
 * Prints the number of presidential race votes by party, then announces
 * the winner.
 */
public void printPresidentialResults()
    throws UnsupportedEncodingException, IOException
{
    // Get a map over the vote database.
    StoredMap map = new StoredMap(dbEnvironment.getVoteByRaceAndPartyDb(),
				  new ByteArrayBinding(),
				  new VoteBinding(), false);

    // For each race, build the key and search for the records matching the
    // key.
    System.out.println("Presidential race results:");
    int winningParty = -1;
    int winningVotes = -1;
    for (int i = 0; i < Vote.NUM_PARTIES; ++i) {
	String key = "" + Vote.RACE_PRESIDENT + ':' + i;

	Collection votes = map.duplicates(key.getBytes("UTF-8"));
	int count = votes.size();
	System.out.println("  " + Vote.partyToString(i) + " party: "
			   + count + " votes");

	if (count > winningVotes) {
	    winningVotes = count;
	    winningParty = i;
	}
    }
    System.out.println("  ...and the winner is the "
		       + Vote.partyToString(winningParty)
		       + " party candidate");
}

/**
 * Empties the databases.
 */
public void emptyDatabases() {
    Transaction txn = null;
    try {
	txn = dbEnvironment.getEnv().beginTransaction(null, null);
	dbEnvironment.getBoothDb().truncate(txn, false);
	dbEnvironment.getVoteDb().truncate(txn, false);
	txn.commit();
    }
    catch (Exception e) {	// DatabaseException, IOException
	try { txn.abort(); }
	catch (DatabaseException dbe2) {}
	ErrorHandler.error("emptyDatabases", e, true);
    }
}

/**
 * usage: VoteServer /path/to/database/directory
 */
public static void main(String[] args) {
    if (args.length == 0)
	ErrorHandler.error("usage: VoteServer /path/to/database/directory",
			   true);

    System.out.println("opening databases read-only");
    VoteServer server = new VoteServer(args[0], true); // Read-only

    System.out.println("running queries");
    server.runQueries();

    System.out.println("shutting down the server");
    server.shutDown();

    System.out.println("done");
}

}
