package jimm.evote;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

/**
 * Utility methods.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class Util {

protected static final String PROPS_FILE = "evote.properties";

protected static Properties props;
protected static Map propsCache = new HashMap();

public static final String[] STATES = { // 50 US states plus D.C.
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI",
    "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN",
    "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH",
    "OK", "OR", "PA", "PR", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VI",
    "VA", "WA", "WV", "WI", "WY"
};

public static String quadToString(byte[] quad) {
    return "" + (int)(quad[0] & 0xff)
	+ '.' + (int)(quad[1] & 0xff)
	+ '.' + (int)(quad[2] & 0xff)
	+ '.' + (int)(quad[3] & 0xff);
}

public static Properties getProperties() {
    if (props == null) {
	props = new Properties();
	try {
	    props.load(new FileInputStream(PROPS_FILE));
	}
	catch (IOException ioe) {
	    System.err.println(ioe.toString());
	    System.exit(1);
	}
    }
    return props;
}

public static String stringParam(String key) {
    String str = (String)propsCache.get(key);
    if (str == null) {
	str = getProperties().getProperty(key);
	propsCache.put(key, str);
    }
    return str;
}

public static int intParam(String key) {
    Integer i = (Integer)propsCache.get(key);
    if (i == null) {
	i = new Integer(getProperties().getProperty(key));
	propsCache.put(key, i);
    }
    return i.intValue();
}

}
