package jimm.evote;

/**
 * Prints time durations; used for development purposes and foolin' around.
 * <p>
 * No threads or system resources are harmed in the making of a stop watch. A
 * stop watch simply remembers the start time (and elapsed time when paused)
 * and prints the total running time (wall clock time) when stopped.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class StopWatch {

protected String name;
protected long t0;
protected long elapsedTime;

/**
 * Constructor.
 */
public StopWatch() {
    this(null);
}

/**
 * Constructor.
 *
 * @param name identifying text
 */
public StopWatch(String name) {
    this.name = name;
}

/**
 * Remembers the current time.
 */
public void start() {
    start(false);
}

/**
 * Remembers the current time and prints a message if requested.
 *
 * @param printStarting if <code>true</code> and this stop watch has a
 * name, print a message
 */
public void start(boolean printStarting) {
    if (t0 != 0)
	System.err.println("(warning: StopWatch already started; resetting)");
    if (printStarting && name != null)
	System.err.println("starting " + name);
    elapsedTime = 0;
    t0 = System.currentTimeMillis();
}

/**
 * Pauses the stop watch.
 */
public void pause() {
    long now = System.currentTimeMillis();
    elapsedTime += now - t0;
    t0 = 0;
}

/**
 * Resumes the stop watch.
 */
public void resume() {
    t0 = System.currentTimeMillis();
}

/**
 * Prints the current elapsed time without stopping.
 */
public void mark() {
    stop(true);
}

/**
 * Prints the current elapsed time without stopping, along with the
 * stop watch name if <var>printMark</var> is <code>true</code>.
 *
 * @param printMark if <code>true</code>, the stop watch name will
 * be printed
 */
public void mark(boolean printMark) {
    stop(printMark);
}

/**
 * Stops the stop watch and prints the current elapsed time.
 */
public void stop() {
    stop(true);
}

/**
 * Stops the stop watch and prints the current elapsed time, along with the
 * stop watch name if <var>printMark</var> is <code>true</code>.
 *
 * @param printName if <code>true</code>, the stop watch name will
 * be printed
 */
public void stop(boolean printName) {
    long now = System.currentTimeMillis();
    long total = elapsedTime;
    if (t0 != 0)
	total += now - t0;

    if (t0 == 0 &&elapsedTime == 0)
	System.err.println("(warning: StopWatch was never started)");

    if (printName && name != null)
	System.err.print(name + ": ");

    System.err.println("" + (total / 1000.0) + " seconds");
}

}
