package jimm.evote;
import jimm.evote.*;
import java.util.*;

/**
 * Simulates election day voting. The method {@link #simulateVoting} creates a
 * bunch of voting {@link Booth}s, has them generate votes, and sends all of
 * the booths' votes to a {@link VoteServer}.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class ElectionDay {

protected Random rand;
protected int boothAddress;

ElectionDay() {
    rand = new Random();
    boothAddress = (192 << 24) + (168 << 16); // 192.168.0.0
}

/**
 * Simulates election day voting. Creates voting booths, generates votes
 * for each booth, and sends the votes to the server. Votes are sent from
 * booths in <var>num_threads</code> chunks, each in a separate thread.
 * <var>num_threads</var> is a parameter read from the properties file.
 *
 * @param server a vote server
 */
public void simulateVoting(VoteServer server) {
    int numVotingBooths = Util.intParam("num_voting_booths");
    int numThreads = Util.intParam("num_threads");
    for (int i = 0; i < numVotingBooths; i += numThreads) {
	int numBooths = Math.min(numThreads, numVotingBooths - i);
	List booths = new ArrayList(numBooths);
	for (int j = 0; j < numBooths; ++j)
	    booths.add(createBooth());

	sendVotesToServer(booths, server);
    }
}

/**
 * Creates and returns a voting booth. The booth's address is unique.
 *
 * @return a new voting booth
 */
protected Booth createBooth() {
    ++boothAddress;
    if ((boothAddress & 0xff) == 0)	// Avoid .0 addresses
	++boothAddress;

    return new Booth(asQuadByteArray(boothAddress),
		     Util.STATES[rand.nextInt(Util.STATES.length)],
		     "City"
		     + (rand.nextInt(Util.intParam("num_cities_per_state")) + 1),
		     "District "
		     + (rand.nextInt(Util.intParam("num_districts_per_city")) + 1));
}

/**
 * Returns an int as a quad byte array.
 */
protected byte[] asQuadByteArray(int address) {
    byte[] quad = new byte[4];
    for (int i = 0; i < 4; ++i)
	quad[i] = (byte)((address >>> ((3 - i) * 8)) & 0xff);
    return quad;
}

/**
 * Sends votes to a vote server using multiple threads so the server gets
 * concurrent updates.
 */
protected void sendVotesToServer(List booths, final VoteServer server) {
    List threads = new ArrayList();

    // Create the threads, add them to a list, and start them.
    for (Iterator iter = booths.iterator(); iter.hasNext(); ) {
	final Booth booth = (Booth)iter.next();
	Thread thread = new Thread(new Runnable() {
	    public void run() {
		booth.generateAndSendVotesTo(server);
	    }});
	threads.add(thread);
	thread.start();
    }

    // Wait for all the threads to finish.
    try {
	for (Iterator iter = threads.iterator(); iter.hasNext(); )
	    ((Thread)iter.next()).join();
    }
    catch (InterruptedException ie) {
	ErrorHandler.error("sendVotesToServer", ie, true);
    }
}

/**
 * Simulates election day voting.
 * <p>
 * usage: ElectionDay /path/to/database/directory
 */
public static void main(String[] args) {
    if (args.length == 0)
	ErrorHandler.error("usage: ElectionDay /path/to/database/directory",
			   true);

    System.out.println("opening/initalizing databases");
    VoteServer server = new VoteServer(args[0]);

    System.out.println("emptying databases");
    server.emptyDatabases();

    System.out.println("generating votes and sending them to the server");
//     StopWatch watch = new StopWatch("election day"); // DEBUG
//     watch.start();		// DEBUG
    new ElectionDay().simulateVoting(server);
//     watch.stop();		// DEBUG

    System.out.println("shutting down the server");
    server.shutDown();

    System.out.println("done");
}

}
