package jimm.evote;

/**
 * A vote stored by a booth.
 * <p>
 * Instead of writing accessor methods, I've made the ivars public.
 * <code>Vote</code>s are essentially simple data structures.
 *
 * @author Jim Menard, <a href="mailto:jimm@io.com">jimm@io.com</a>
 */
public class Vote {

public static final int RACE_PRESIDENT = 0;
public static final int RACE_SENATE = 1;
public static final int RACE_CONGRESS = 2;
public static final int RACE_GOVERNOR = 3;
public static final int RACE_STATE_ASSEMBLY = 4;
public static final int RACE_DOG_CATCHER = 5;
public static final int NUM_RACES = 6;

public static final int PARTY_DEMOCRAT = 0;
public static final int PARTY_REPUBLICAN = 1;
public static final int PARTY_INDEPENDENT = 2;
public static final int PARTY_LIBERTARIAN = 3;
public static final int PARTY_GREEN = 4;
public static final int PARTY_SILLY = 5;
public static final int NUM_PARTIES = 6;

/** Primary key. */
public String key;
/** Booth IP address. Foreign key, so to speak. */
public byte[] boothAddress;
/**
 * This vote's sequence number, assigned to it by a voting booth. Not globally
 * unique, but unique within a voting booth.
 */
public int voteNum;
/**
 * Used to group votes by a single person together. This way, we can report on
 * how many voters voted a straight party ticket, for example.
 */
public int voteBlockId;
/** Race (<code>RACE_PRESIDENT</code>, etc.) */
public int race;
/** Candidate ID number. */
public int candidateID;
/** Identifies the candidate's party (<code>PARTY_SILLY</code>, etc.) */
public int candidateParty;

public static String raceToString(int race) {
    switch (race) {
    case RACE_PRESIDENT: return "President";
    case RACE_SENATE: return "Senate";
    case RACE_CONGRESS: return "Congress";
    case RACE_GOVERNOR: return "Governor";
    case RACE_STATE_ASSEMBLY: return "State Assembly";
    case RACE_DOG_CATCHER: return "Dog Catcher";
    default: return "(unknown race)";
    }
}

public static String partyToString(int party) {
    switch (party) {
    case PARTY_DEMOCRAT: return "Democratic";
    case PARTY_REPUBLICAN: return "Republican";
    case PARTY_INDEPENDENT: return "Independent";
    case PARTY_LIBERTARIAN: return "Libertarian";
    case PARTY_GREEN: return "Green";
    case PARTY_SILLY: return "Silly";
    default: return "(unknown party)";
    }
}

/**
 * Constructor.
 *
 * @param boothAddress the voting booth's address
 * @param voteNum assigned by the voting booth
 * @param voteBlockId assigned by the voting booth
 * @param race <code>RACE_PRESIDENT</code>, etc.
 * @param candidateID candidate ID number
 * @param candidateParty <code>PARTY_SILLY</code>, etc.
 */
public Vote(byte[] boothAddress, int voteNum, int voteBlockId,
	    int race, int candidateID, int candidateParty)
{
    // Generate a unique key
    key = Util.quadToString(boothAddress) + ":" + voteNum;

    this.boothAddress = boothAddress;
    this.voteNum = voteNum;
    this.voteBlockId = voteBlockId;
    this.race = race;
    this.candidateID = candidateID;
    this.candidateParty = candidateParty;
}

public String toString() {
    return "[Vote key=" + key + ", race = " + race + "]";
}

}
