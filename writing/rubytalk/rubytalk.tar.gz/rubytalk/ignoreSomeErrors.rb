#! /usr/bin/env ruby

threshold = ARGV[0] ? ARGV[0].to_i : 15

printedPrev = false
$stdin.each { | line |
    if line =~ /^Overfull \\hbox \((\d+)\.\d*pt too wide\)/
	if $1.to_i >= threshold
	    print line
	    printedPrev = true
	end
    elsif printedPrev
	print line
	printedPrev = false
    end
}
