#! /usr/bin/env ruby

require 'drb'

DRb.start_service()
serverObj = DRbObject.new(nil, 'druby://localhost:9000')

x = 5
serverObj.useRemoteContext { | y | x += y }
puts x
