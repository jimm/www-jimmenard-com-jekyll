#include "Song.h"

main()
{
    Song s("name", 60);
    cout << s << endl;
}
