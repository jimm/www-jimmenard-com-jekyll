import java.io.*;
import java.util.*;

public class DataFileReader {

public static void main(String[] args) {
    DataFileReader dfr = new DataFileReader();
    dfr.readFile(args[0]);
}

public void readFile(String fileName) {
    try {
        BufferedReader in =
            new BufferedReader(new FileReader(fileName));
        String line;
        while ((line = in.readLine()) != null) {
            Collection list = splitIntoColumns(line);
	    printAsInsertStatements(list);
        }
    }
    catch (FileNotFoundException fnfe) {
        System.err.println(fnfe.toString());
    }
    catch (IOException ioe) {
        System.err.println(ioe.toString());
    }
}

public Collection splitIntoColumns(String line) {
    ArrayList array = new ArrayList();

    // Using StringTokenizer here is almost useless. It either
    // skips or returns multiple adjacent commas, but doesn't
    // report the emptyness between as empty data columns.
    int pos = line.indexOf(",");
    while (pos != -1) {
	array.add(line.substring(0, pos));
	line = line.substring(pos + 1);
	pos = line.indexOf(",");
    }
    if (line.length() > 0)
	array.add(line);

    return array;
}

public void printAsInsertStatements(Collection list) {
    System.out.print("insert into table values (\n\t");
    boolean first = true;

    for (Iterator iter = list.iterator(); iter.hasNext(); ) {
	String col = (String)iter.next();

	if (first) first = false;
	else System.out.print(",\n\t");

	System.out.print("'" + col + "'");
    }
    System.out.println("\n)");
}

}

