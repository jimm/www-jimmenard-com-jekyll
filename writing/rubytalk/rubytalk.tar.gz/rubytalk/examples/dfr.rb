#! /usr/local/bin/ruby

# File is a subclass of IO. "foreach" is a class method that
# opens the file, executes the block of code once for each line,
# and closes the file.
IO.foreach(ARGV[0]) { | line |
    line.chomp!()
    puts "insert into table values ("
    print "\t'"
    print line.split(/,/).join("',\n\t'")
    puts "'\n)"
}
