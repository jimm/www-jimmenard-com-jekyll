#! /usr/bin/env ruby

class TestServer
    def useRemoteContext
	yield 42
    end
end

ts = TestServer.new()
x = 5
ts.useRemoteContext { | y | x += y }
puts x
