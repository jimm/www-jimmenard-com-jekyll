#include <vector>
#include "Song.h"

main()
{
    vector<Song> songs;
    songs.push_back(Song("name", 60));

    vector<Song>::iterator iter(songs.begin());
    for ( ; iter != songs.end(); ++iter) {
	Song s = *iter;
	// Do something with s...
    }
}
