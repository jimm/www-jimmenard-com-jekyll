#ifndef Song_h
#define Song_h

#include <iostream>
#include <string>

class Song {
public:
    Song(const char * nameStr = 0, int len = 0)
	: name(nameStr ? nameStr : ""), lengthInSeconds(len) {}

    // The default copy constructor, destructor, and operator=
    // are all acceptable. I'm glad, 'cause it's a pain to have
    // to write them.

    const char * getName() const { return name.data(); }
    void setName(const char *str) { name = str; }

    int getLengthInSeconds() const { return lengthInSeconds; }
    void setLengthInSeconds(int len) { lengthInSeconds = len; }

protected:
    string name;
    int lengthInSeconds;

    friend ostream & operator<<(ostream &out, const Song &s);
};

ostream & operator<<(ostream &out, const Song &s) {
    return out << s.name << " (" << s.lengthInSeconds << " seconds)";
}

#endif Song_h
