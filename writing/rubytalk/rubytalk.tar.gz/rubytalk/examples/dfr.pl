#! /usr/bin/perl

open(FILE, $ARGV[0]) || die "can't open file $ARGV[0]: $!\n";
print "$ARGV[0] opened\n";
#while (($line = <FILE>) != '') {
while (($line = <FILE>) ne '') {
    chomp($line);
    print "insert into table values (\n\t'";
    print join("',\n\t'", split(/,/, $line));
    print "'\n)\n";
}
close(FILE);
