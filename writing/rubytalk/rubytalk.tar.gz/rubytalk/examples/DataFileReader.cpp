#include <string>
#include <iostream>
#include <fstream>
#include <vector>

static const int BUFSIZ = 1024;

vector<string> splitIntoColumns(char *line);
void printAsInsertStatements(vector<string> &list);

void
main(int argc, char *argv[])
{
    ifstream in(argv[1]);
    char line[BUFSIZ];
    while (!in.eof()) {
	in.getline(line, BUFSIZ);
	if (strlen(line) == 0)
	    break;
	vector<string> list = splitIntoColumns(line);
	printAsInsertStatements(list);
    }
}

vector<string>
splitIntoColumns(char *line)
{
    vector<string> list;

    // Using strtok() here is useless. It skips multiple
    // adjacent commas and doesn't report the emptyness
    // between as empty data columns.
    char *nextComma = index(line, ',');
    while (nextComma != 0) {
	list.push_back(string(line, nextComma - line));
	line = nextComma + 1;
	nextComma = index(line, ',');
    }
    if (strlen(line) > 0)
	list.push_back(string(line));

    return list;
}

void
printAsInsertStatements(vector<string> &list)
{
    cout << "insert into table values (" << endl << "\t";
    bool first = true;

    vector<string>::iterator iter;
    for (iter = list.begin(); iter != list.end(); ++iter) {
	string col = *iter;

	if (first) first = false;
	else cout << "," << endl << "\t";

	cout << "'" << col << "'";
    }
    cout << endl << ")" << endl;
}

