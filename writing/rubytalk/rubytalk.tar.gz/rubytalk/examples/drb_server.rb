#! /usr/bin/env ruby

require 'drb'

class TestServer
    def useRemoteContext
	yield 42
    end
end

serverObj = TestServer.new()
DRb.start_service('druby://localhost:9000', serverObj)

puts DRb.uri
puts '[return] to exit'
gets
