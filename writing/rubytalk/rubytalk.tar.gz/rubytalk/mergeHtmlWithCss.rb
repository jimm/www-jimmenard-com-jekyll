#! /usr/bin/env ruby

IO.foreach("talk/talk.html") { | line |
    next if line =~ /\<META HTTP-EQUIV="Content-Style-Type" CONTENT="text\/css">/
    if line =~ /\<LINK REL="STYLESHEET" HREF="talk.css">/
	puts '<style type="text/css">'
	puts '<!--'
	IO.foreach("talk/talk.css") { | css |
	    print css
	}
	puts '-->'
	puts '</style>'
    else
	print line
    end
}
